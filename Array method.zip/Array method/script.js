// Array method 


// Join
// var arr = [1, 2, 3, 4,]
// var x = 10

// for(var i = 0; i <= x; i++){
//     y = i
//     y = ','
//     console.log(arr.join(y).split());
// }


// pop suulin element ustgana

// var  arr = ['0', '1', '2', '3', '4', '5']

// for(var i = 0; i = arr.length; i++){
//     if(arr.pop().length){
//         console.log(arr);
//     }
// }


// push 

// var x = prompt('oruulah utgaa oruulanuu');
// var arr = [];
// for(var i = 0; i < x.length; i++){
//     console.log(x[i])
//     arr.push(x[i])
// }



// shift ehnii elemntiig songono


// var arr = ['3', '2', '4']
// var x = arr.shift();
// console.log(parseInt(x));



// unshift hamgiin ehend utga nemeh

// var arr = ['3', '2', '4']
// var x = arr.unshift('unshift');
// console.log(arr);


// index 


// var arr = ['0', '3', '4']

// arr[2] =  'ene utga tuhain indexeer soligdlooo'
// console.log(arr)
// concat 


// var arr = [1, 2, 3, 4, 5]
// var arr1 = ['string1', 'string2']
// var arr2 = [0, 2]

// var negtgeh = arr.concat(arr2, arr1)
// console.log(negtgeh)



// reverse suliinhees ehluulj bodogduulna 



// indexOf tuhain data niii hedden indexiig haruulna

// tyfeOf tuhain data nii data typiin shalgana jisheen 5 gesen number bval number gedgiin hevlne
